# snakexorcist
GAMES DESCRIPTION: Snakexorcist is a 2D action platformer rooted in Chinese mythology. The game is a blend of fast-paced combat and exploration in a pixel-art style. Following the story of Xu Shilin, an exorcist goes on a mission to free the White Snake from the captivity of the evil monk Fahai. The game integrates elements of traditional Chinese folklore into its narrative, creating a world filled with mystical creatures, ancient magic, and dangerous spirits.

Players must navigate through three levels: the castle exterior, the castle interior, and the boss battle. The first level takes place outside of the castle, where Xu Shilin must battle enemies such as badger and eagle spirits to break the seal protecting the castle. Once Xu Shilin can reach and unlock the castle gates, he will begin the second level which takes place within the interior. He must ascend through many platforms, encountering various challenges, including bat and mice spirits, to reach the top and confront Fahai in a boss battle. Dialogue will be present throughout the game, providing important context to advance the story.

LINK TO GAME: https://drive.google.com/file/d/1-rSAWVwNFL0YkJC2yzXhlx0nczJJxiGc/view?usp=drive_link

LINK TO VIDEO: https://drive.google.com/file/d/1AbAMwS0oWqBDOW0pozEs8_3EMWfIn8sh/view?usp=drive_link 

Download and unzip the file, the application will be named "Snakecersist", open it and play!

CONTROLS:

D - Move Right
A - Move Left
Space - Jump
Left Mouse Button - Melee Attack
Right Mouse Button - Ranged Attack
T - Interaction Key (for dialogue NPC’s)
